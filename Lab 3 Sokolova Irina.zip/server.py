import zmq
import sys

port = "5555"
port1 = "5556"
port2 = "5557"
port3 = "5558"
if len(sys.argv) > 1:
    port = sys.argv[1]
    int(port)

if len(sys.argv) > 2:
    port1 = sys.argv[2]
    int(port1)

if len(sys.argv) > 3:
    port2 = sys.argv[3]
    int(port2)

if len(sys.argv) > 4:
    port3 = sys.argv[4]
    int(port3)

context = zmq.Context()
client_input = context.socket(zmq.REP)
client_output = context.socket(zmq.PUB)
client_input.bind(f"tcp://127.0.0.1:{port}")
client_output.bind(f"tcp://127.0.0.1:{port1}")
worker_input = context.socket(zmq.PUB)
worker_output = context.socket(zmq.SUB)
worker_input.bind(f"tcp://127.0.0.1:{port2}")
worker_output.bind(f"tcp://127.0.0.1:{port3}")

try:
    while True:
    	msg = client_input.recv_string()
    	client_input.send_string(msg)
    	worker_input.send_string(msg)
    	try:
        	while True:
            		response = worker_output.recv_string()
            		if response:
                	client_output.send_string(response)
    	except zmq.Again:
        	pass
except zmq.Again:
    pass
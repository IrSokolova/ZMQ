import zmq
import sys

def is_prime(n):
    if n in (2, 3):
        return True
    if n % 2 == 0:
        return False
    for divisor in range(3, n, 2):
        if n % divisor == 0:
            return False
    return True


port = "5557"
port1 = "5558"
if len(sys.argv) > 1:
    port = sys.argv[1]
    int(port)

if len(sys.argv) > 2:
    port1 = sys.argv[2]
    int(port1)

context = zmq.Context()
worker_input = context.socket(zmq.SUB)
worker_output = context.socket(zmq.PUB)
worker_input.connect(f"tcp://127.0.0.1:{port}")
worker_output.connect(f"tcp://127.0.0.1:{port1}")
worker_input.setsockopt_string(zmq.SUBSCRIBE, 'isprime')

worker_input.RCVTIMEO = 100
try:
    msg = worker_input.recv_string()
    command, number = msg.split()
    if command == 'isprime' and int(number):
        if is_prime(int(number)):
            worker_output.send_string(number + ' is prime')
        else:
            worker_output.send_string(number + ' is not prime')
except zmq.Again:
    pass

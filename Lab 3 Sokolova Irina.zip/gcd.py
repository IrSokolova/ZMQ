import zmq
import sys
from fractions import gcd


port = "5557"
port1 = "5558"
if len(sys.argv) > 1:
    port = sys.argv[1]
    int(port)

if len(sys.argv) > 2:
    port1 = sys.argv[2]
    int(port1)

context = zmq.Context()
worker_input = context.socket(zmq.SUB)
worker_output = context.socket(zmq.PUB)
worker_input.connect(f"tcp://127.0.0.1:{port}")
worker_output.connect(f"tcp://127.0.0.1:{port1}")
worker_input.setsockopt_string(zmq.SUBSCRIBE, 'gcd')

worker_input.RCVTIMEO = 100
try:
    msg = worker_input.recv_string()
    command, numbers = msg.split()
    A, B = numbers.split()
    if command == 'gcd' and int(B):
        worker_output.send_string('gcd for ' + A + ' ' + B + ' is ' + str(gcd(int(A), int(B))))
except zmq.Again:
    pass

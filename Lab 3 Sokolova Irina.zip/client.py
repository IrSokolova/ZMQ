import zmq
import sys

port = "5555"
port1 = "5556"
if len(sys.argv) > 1:
    port = sys.argv[1]
    int(port)

if len(sys.argv) > 2:
    port1 = sys.argv[2]
    int(port1)

context = zmq.Context()
client_input = context.socket(zmq.REQ)
client_output = context.socket(zmq.SUB)
client_input.connect(f"tcp://127.0.0.1:{port}")
client_output.connect(f"tcp://127.0.0.1:{port1}")

try:
    while True:
        line = input("> ")
        if len(line) != 0:
            client_input.send_string(line)
            message = client_input.recv_string()
            if message == line:
                print('Message delivered')
        try:
            while True:
                response = client_output.recv_string()
                if response:
                    print(response)
        except zmq.Again:
            pass
except KeyboardInterrupt:
    print("Terminating client")
    sys.exit(0)